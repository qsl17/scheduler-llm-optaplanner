package com.example.eventassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventAssignmentApplication.class, args);
	}

}
